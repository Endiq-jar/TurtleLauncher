TURTLELAUNCHER — 2,048 NEW ICONS + ORIGINAL

Open index.html in a browser after extracting the ZIP to browse and filter.

png/       2,048 new 512 x 512 pixel-art app-icon concepts, RGB PNG.
svg/       2,048 matching scalable vectors (pixel geometry, not embedded PNGs).
original/  Unmodified repository launcher PNG and full turtle WebP artwork.
PREVIEW.jpg  A sample of 64 icons (not the entire collection).
manifest.csv / manifest.json  Names, design parameters, pixel and silhouette hashes.

These are procedurally drawn designs inspired by the existing pixel turtle.
They vary anatomy, pose, shell pattern, accessories, theme and background.
All 2,048 pixel hashes AND binary foreground silhouette hashes are unique.
The generator checks both before packaging. Color differences alone are not
used as the uniqueness criterion. Subjective resemblance is still possible
within a related turtle-icon family; these are not 2,048 unrelated brands.

SVGs are crisp vector pixel art, not smooth Bezier illustrations.
PNGs have opaque square backgrounds. These are design concepts, not an
Android adaptive-icon installation pack. No app resources were replaced.

The original artwork is from Endiq-jar/TurtleLauncher; the repository license
is included as LICENSE.repository. No separate trademark rights are granted.
Reproduce using tools/generate_turtle_icon_pack.py (Python + Pillow).
