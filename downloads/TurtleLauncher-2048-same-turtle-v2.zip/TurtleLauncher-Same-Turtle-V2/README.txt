TURTLELAUNCHER — ORIGINAL SHAPE EDITION (V2)

2,048 new variants + byte-for-byte unchanged original icon.
Open index.html after extracting to browse and filter offline.

png/: 2,048 512x512 PNGs. svg/: 2,048 matching pixel-vector SVGs.
original/original.png: unchanged repository launcher icon.
original/extracted-turtle.png: actual turtle, transparent background, no redraw.
source-palettes/: the same exact turtle in 16 color palettes.
PREVIEW.jpg: 64 samples. manifest.csv / manifest.json: complete catalog.

Every turtle uses the SAME position, shape, silhouette, pixel regions, face,
eye, shell, legs and tail as the original. No flipping, rotation, new poses,
new anatomy, drawing over the turtle, or replacement shell patterns.
Only 1:1 color palette substitutions are allowed. Palette Original keeps the
original turtle colors. Decorations stay outside a four-pixel safety margin.

16 palettes x 16 scene backgrounds x 8 decoration styles = 2,048 icons.
All 2,048 full images have unique pixel hashes. All turtle alpha hashes must
be IDENTICAL. Every turtle pixel is checked against its palette source.
This is a family of variants of ONE logo, not 2,048 different turtle shapes.
Generated procedurally with Pillow, not by an image model. Original is from
Endiq-jar/TurtleLauncher. Repository license included; no trademark rights
are granted. These are artwork PNGs, not an Android adaptive-icon installer.
